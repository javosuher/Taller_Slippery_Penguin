package com.me.ejercicio1;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public class GameScreen implements Screen { // Implementa la interfaz de Screen, es decir, se comportara con las caracteristicas de una pantalla
	// sus funciones se llaman automaticamente cuando ocurre el evento al que estan asociadas (renderizar,
	//reescalar, pausar, resumir...) menos con dispose, para liberar los recursos hay que llamar a dispose manualmente
	
	private Ejercicio1 sp;
	private Texture texturaFondo; // Una Texture es una clase que envuelve una textura estandar de OpenGL, se utiliza para imagenes simples.
	private SpriteBatch batch; // "Grupo de Sprites (imagenes)" nos permite dibujar rectagulos como referencias a texturas, es necesario para mostrar todo por pantalla.
	
	public GameScreen(Ejercicio1 slipperypenguin) { // Constructor de la clase.
		this.sp = slipperypenguin;
		
		//Creamos las texturas, primero el fondo del juego.
		
		// MAKE: Asignar la textura correspondiente a texturaFondo para poder dibujar el fondo de pantalla.
		
		batch = new SpriteBatch(); // Es recomendable tener solo uno por juego.
	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0, 1); //Gdx es una clase con la que podemos acceder a variables que hacen referencia a todos los subsitemas, como son graficos, audio, ficheros, entrada y aplicaciones
		// gl es una variable de tipo GL, nos permite acceder a metodos de GL10, GL11 y GL20
		//En este caso glClearColor es un bucle (game loop) que establecera el fondo de la pantalla negro (0,0,0) con transparencia 1
		Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT); // Despues de la funcion anterior es necesario ejecutar esta, para que se lleve a cabo
		
		batch.begin(); // Aqui por fin comenzamos el renderizado
		
		// Dibujamos el fondo en la posición x = 0 e y = 0.
		
		// MAKE: Dibujar el fondo de pantalla en la cordenada x = 0 e y = 0, con la anchura y altura de la imagen.
		
		batch.end(); // Terminamos el renderizado.
	}
	
	@Override
	public void show() { // Método que se ejecuta cuando la pantalla actual pasa a estar activa.
		// TODO Auto-generated method stub
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
	}
	
	@Override
	public void dispose() { // Cuando se termina la aplicación
		// TODO Auto-generated method stub
	}
}
