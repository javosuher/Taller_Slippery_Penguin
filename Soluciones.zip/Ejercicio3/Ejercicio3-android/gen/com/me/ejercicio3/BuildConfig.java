/** Automatically generated file. DO NOT MODIFY */
package com.me.ejercicio3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}